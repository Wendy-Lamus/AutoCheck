using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class ConcesionarioController:Controller{
 private readonly AppDbContext _ctx;
 public ConcesionarioController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Concesionarios.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Concesionario m){_ctx.Concesionarios.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Concesionarios.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Concesionario m){_ctx.Concesionarios.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Concesionarios.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Concesionarios.Find(id);_ctx.Concesionarios.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
