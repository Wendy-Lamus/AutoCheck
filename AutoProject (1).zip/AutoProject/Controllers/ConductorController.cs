using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class ConductorController:Controller{
 private readonly AppDbContext _ctx;
 public ConductorController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Conductors.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Conductor m){_ctx.Conductors.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Conductors.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Conductor m){_ctx.Conductors.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Conductors.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Conductors.Find(id);_ctx.Conductors.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
