using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class Documento_transporteController:Controller{
 private readonly AppDbContext _ctx;
 public Documento_transporteController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Documento_transportes.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Documento_transporte m){_ctx.Documento_transportes.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Documento_transportes.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Documento_transporte m){_ctx.Documento_transportes.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Documento_transportes.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Documento_transportes.Find(id);_ctx.Documento_transportes.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
