using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class Documentos_envioController:Controller{
 private readonly AppDbContext _ctx;
 public Documentos_envioController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Documentos_envios.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Documentos_envio m){_ctx.Documentos_envios.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Documentos_envios.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Documentos_envio m){_ctx.Documentos_envios.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Documentos_envios.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Documentos_envios.Find(id);_ctx.Documentos_envios.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
