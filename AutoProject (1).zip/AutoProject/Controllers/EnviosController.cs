using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class EnviosController:Controller{
 private readonly AppDbContext _ctx;
 public EnviosController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Envioss.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Envios m){_ctx.Envioss.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Envioss.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Envios m){_ctx.Envioss.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Envioss.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Envioss.Find(id);_ctx.Envioss.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
