using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class InventarioController:Controller{
 private readonly AppDbContext _ctx;
 public InventarioController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Inventarios.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Inventario m){_ctx.Inventarios.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Inventarios.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Inventario m){_ctx.Inventarios.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Inventarios.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Inventarios.Find(id);_ctx.Inventarios.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
