using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class NotificacionController:Controller{
 private readonly AppDbContext _ctx;
 public NotificacionController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Notificacions.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Notificacion m){_ctx.Notificacions.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Notificacions.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Notificacion m){_ctx.Notificacions.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Notificacions.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Notificacions.Find(id);_ctx.Notificacions.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
