using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class NovedadesController:Controller{
 private readonly AppDbContext _ctx;
 public NovedadesController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Novedadess.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Novedades m){_ctx.Novedadess.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Novedadess.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Novedades m){_ctx.Novedadess.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Novedadess.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Novedadess.Find(id);_ctx.Novedadess.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
