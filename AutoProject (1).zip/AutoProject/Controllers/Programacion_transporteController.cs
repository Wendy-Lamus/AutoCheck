using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class Programacion_transporteController:Controller{
 private readonly AppDbContext _ctx;
 public Programacion_transporteController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Programacion_transportes.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Programacion_transporte m){_ctx.Programacion_transportes.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Programacion_transportes.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Programacion_transporte m){_ctx.Programacion_transportes.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Programacion_transportes.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Programacion_transportes.Find(id);_ctx.Programacion_transportes.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
