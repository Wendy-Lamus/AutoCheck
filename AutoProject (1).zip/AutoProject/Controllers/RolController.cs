using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class RolController:Controller{
 private readonly AppDbContext _ctx;
 public RolController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Rols.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Rol m){_ctx.Rols.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Rols.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Rol m){_ctx.Rols.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Rols.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Rols.Find(id);_ctx.Rols.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
