using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class RutaController:Controller{
 private readonly AppDbContext _ctx;
 public RutaController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Rutas.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Ruta m){_ctx.Rutas.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Rutas.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Ruta m){_ctx.Rutas.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Rutas.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Rutas.Find(id);_ctx.Rutas.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
