using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class Seguimiento_enviosController:Controller{
 private readonly AppDbContext _ctx;
 public Seguimiento_enviosController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Seguimiento_envioss.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Seguimiento_envios m){_ctx.Seguimiento_envioss.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Seguimiento_envioss.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Seguimiento_envios m){_ctx.Seguimiento_envioss.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Seguimiento_envioss.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Seguimiento_envioss.Find(id);_ctx.Seguimiento_envioss.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
