using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class Transportes_programadosController:Controller{
 private readonly AppDbContext _ctx;
 public Transportes_programadosController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Transportes_programadoss.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Transportes_programados m){_ctx.Transportes_programadoss.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Transportes_programadoss.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Transportes_programados m){_ctx.Transportes_programadoss.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Transportes_programadoss.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Transportes_programadoss.Find(id);_ctx.Transportes_programadoss.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
