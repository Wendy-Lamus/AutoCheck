using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class UsuarioController:Controller{
 private readonly AppDbContext _ctx;
 public UsuarioController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Usuarios.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Usuario m){_ctx.Usuarios.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Usuarios.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Usuario m){_ctx.Usuarios.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Usuarios.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Usuarios.Find(id);_ctx.Usuarios.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
