using Microsoft.AspNetCore.Mvc;
using AutoProject.Data;
using AutoProject.Models;
using System.Linq;

namespace AutoProject.Controllers{
public class VehiculoController:Controller{
 private readonly AppDbContext _ctx;
 public VehiculoController(AppDbContext ctx){_ctx=ctx;}
 public IActionResult Index()=>View(_ctx.Vehiculos.ToList());
 public IActionResult Create()=>View();
 [HttpPost] public IActionResult Create(Vehiculo m){_ctx.Vehiculos.Add(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Edit(int id){var m=_ctx.Vehiculos.Find(id);return View(m);}
 [HttpPost] public IActionResult Edit(Vehiculo m){_ctx.Vehiculos.Update(m);_ctx.SaveChanges();return RedirectToAction("Index");}
 public IActionResult Delete(int id){var m=_ctx.Vehiculos.Find(id);return View(m);}
 [HttpPost,ActionName("Delete")] public IActionResult DeleteConfirmed(int id){var m=_ctx.Vehiculos.Find(id);_ctx.Vehiculos.Remove(m);_ctx.SaveChanges();return RedirectToAction("Index");}
}
}
