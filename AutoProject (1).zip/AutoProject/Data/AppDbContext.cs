using Microsoft.EntityFrameworkCore;
namespace AutoProject.Data{public class AppDbContext:DbContext{public AppDbContext(DbContextOptions<AppDbContext> o):base(o){}public DbSet<AutoProject.Models.Concesionario> Concesionarios {get;set;}
public DbSet<AutoProject.Models.Conductor> Conductors {get;set;}
public DbSet<AutoProject.Models.Correciones> Correcioness {get;set;}
public DbSet<AutoProject.Models.Documentos_envio> Documentos_envios {get;set;}
public DbSet<AutoProject.Models.Documento_transporte> Documento_transportes {get;set;}
public DbSet<AutoProject.Models.Envio> Envios {get;set;}
public DbSet<AutoProject.Models.Envios> Envioss {get;set;}
public DbSet<AutoProject.Models.Inventario> Inventarios {get;set;}
public DbSet<AutoProject.Models.Notificacion> Notificacions {get;set;}
public DbSet<AutoProject.Models.Novedad> Novedads {get;set;}
public DbSet<AutoProject.Models.Novedades> Novedadess {get;set;}
public DbSet<AutoProject.Models.Pedido> Pedidos {get;set;}
public DbSet<AutoProject.Models.Programacion_transporte> Programacion_transportes {get;set;}
public DbSet<AutoProject.Models.Rol> Rols {get;set;}
public DbSet<AutoProject.Models.Ruta> Rutas {get;set;}
public DbSet<AutoProject.Models.Seguimiento_envios> Seguimiento_envioss {get;set;}
public DbSet<AutoProject.Models.Transporte> Transportes {get;set;}
public DbSet<AutoProject.Models.Transportes_programados> Transportes_programadoss {get;set;}
public DbSet<AutoProject.Models.Usuario> Usuarios {get;set;}
public DbSet<AutoProject.Models.Vehiculo> Vehiculos {get;set;}
}}